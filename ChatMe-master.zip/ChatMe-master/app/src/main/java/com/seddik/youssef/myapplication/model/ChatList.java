package com.seddik.youssef.myapplication.model;

public class ChatList {
    String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ChatList(String id) {
        this.id = id;
    }

    public ChatList() {

    }
}
