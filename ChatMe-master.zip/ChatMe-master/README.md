Chat app provide communication between individual and groups.
you can view online friends and chat with them realtime.

tools : Android studio, firebase database, onesignal notification, google material design.


![image](https://github.com/youssefseddik/AndroidProjects/blob/master/1.png)
![image](https://github.com/youssefseddik/AndroidProjects/blob/master/2.png)
![image](https://github.com/youssefseddik/AndroidProjects/blob/master/3.png)
![image](https://github.com/youssefseddik/AndroidProjects/blob/master/4.png)
![image](https://github.com/youssefseddik/AndroidProjects/blob/master/5.png)
![image](https://github.com/youssefseddik/AndroidProjects/blob/master/6.png)
![image](https://github.com/youssefseddik/AndroidProjects/blob/master/7.png)
![image](https://github.com/youssefseddik/AndroidProjects/blob/master/8.png)

